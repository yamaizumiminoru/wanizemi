<!-- ver20260723165649 -->
<!--
役割: コーパス研究と量的・統計的研究の方法
発火条件: 検索式、頻度、共起、変数、測定、相関、比較、統計が主要課題
このファイルが正本となる事項: コーパス範囲、操作化、統計操作、再現性、推論限界
このファイルが担当しない事項: 質的解釈、混合統合、章立ての正本
主な委譲先: `MethodQuestions.md`、`Review_Evidence_Sections.md`、`OutlineTemplates.md`
-->

# Quantitative and Corpus Methods

## 共通運用原則

- 方法名やデータ形式だけで決めず、研究目的・問い・対象・必要な証拠に合わせる。
- 次の論証鎖を追う：**目的・問い → 資料・データ → 分析操作 → 判定・解釈基準 → 観察 → 解釈・結論 → 推論の橋**。
- 所属機関の倫理、権利、提出要件と、実際に採用する方法論文献を確認する。
- 人数、期間、ツール、手順は候補例であり、普遍的な必須条件ではない。
- データ量、ソフト名、専門用語を妥当性の代理にしない。
- 章立ての正本は`OutlineTemplates.md`、方法選定の正本は`MethodQuestions.md`とする。
- 参考文献、ツール、コーパス、リンクは利用前に書誌、版、提供状況、ライセンスを確認する。

## 使用時の7点確認

1. 何に答える方法か
2. 使わない方がよい条件
3. 必要な資料・データ
4. 実際の分析操作
5. 分類・判定・解釈基準
6. 妥当性・限界・倫理
7. 次に接続する作業

## Digital Corpus Guide – 日本語コーパス活用ハンドブック

*BCCWJ / CSJ / NWJC / UniDic + Python & AntConc 実践*

---

### 1. 日本語コーパスと関連ツール

| 名称 | 種類・収録内容 | 規模 | 利用方法 | 公式資料 |
| --- | --- | --- | --- | --- |
| **BCCWJ 第1部（BCCWJ1）** | 現代の書き言葉を集めた均衡コーパス。書籍・雑誌・新聞・ブログなど | 1億430万語 | 少納言で文字列を検索。中納言では利用登録後に語を検索 | [国語研・BCCWJ第1部](https://clrd.ninjal.ac.jp/bccwj/index.html) |
| **CSJ** | 日本語話し言葉コーパス。学会講演などの自発音声と転記を収録 | 約750万語 | 中納言で短単位の形態論情報を無償検索。音声を含むオリジナル版は有償 | [国語研・CSJの利用方法](https://clrd.ninjal.ac.jp/csj/chunagon.html) |
| **NWJC** | 国語研日本語ウェブコーパス。ウェブから収集した日本語テキスト | 約258億短単位（2014年10～12月収集分） | 語彙表を公開。全データは共同研究を通じて利用。検索サービス「梵天」とNWJCの中納言版は終了 | [開発プロジェクト・統計と利用方法](https://masayu-a.github.io/NWJC/) |
| **太陽コーパス** | 総合雑誌『太陽』の通常号。1895・1901・1909・1917・1925年の全文 | 約1,450万字（原版） | 形態論情報を加えた更新版は『日本語歴史コーパス』「明治・大正編Ⅰ雑誌」の一部として中納言で検索 | [国語研・太陽コーパス](https://clrd.ninjal.ac.jp/cmj/taiyou/) |
| **まとめて検索『KOTONOHA』** | 中納言で複数のコーパスを横断検索するサービス | 選んだコーパスによる | 中納言に登録し、利用許諾を得たコーパスをまとめて検索・比較 | [国語研・KOTONOHA](https://clrd.ninjal.ac.jp/kotonoha.html) |
| **UniDic** | 日本語を短単位で分割し、品詞などを付ける形態素解析用辞書 | 辞書の種類・版による | 対象資料の時代・文体に合う辞書を選び、公式サイトから入手 | [国語研・UniDic](https://clrd.ninjal.ac.jp/unidic/) |

---

### 2. 基本ワークフロー（例：終助詞「ね」の年代差）

1. **問い定義**：「若年層 SNS 書き言葉における終助詞『ね』使用率は変化したか？」  
2. **コーパス選定**：BCCWJ Web+ブログ & NWJC  
3. **検索式**：`"ね\s*$"` で文末抽出  
4. **頻度集計**：年代別 KWIC → 頻度表  
5. **統計解析**：χ² 検定で差の有無確認  
6. **質的読解**：例文を Textual Hermeneutics で分類  
7. **報告**：Joint Display（棒グラフ＋引用例）

---

### 3. ツール別クイックスタート

#### 3.1 NINJAL-Lab / Sketch Engine (ブラウザ)

* UI からコーパスを選択 → **サブコーパスフィルタ**(媒体・年代) → Concordance。
* **CQL** 例: `[lemma="食べる" & pos="動詞"]"たい"` で「食べたい」。

#### 3.2 AntConc + BCCWJ Mini

```bash

#### 実行例：BCCWJ-Mini（約1M語）をダウンロード→テキスト結合
awk '{print $0"\n"}' *.txt > bccwj_mini.txt
```

* AntConc → File → Open Corpus → `bccwj_mini.txt`。
* Concordance→Search Term: `ね` → Sort by Right 1 で用法比較。

#### 3.3 Python + MeCab/UniDic

```python
import pandas as pd, MeCab
mecab = MeCab.Tagger('-Ochasen -d /usr/local/lib/mecab/dic/unidic')
with open('nwjc_sample.txt') as f:
    lines = [l.strip() for l in f]
lemma_counts = {}
for ln in lines:
    node = mecab.parseToNode(ln)
    while node:
        lemma = node.feature.split(',')[7]  # UniDic: 原形
        lemma_counts[lemma] = lemma_counts.get(lemma, 0)+1
        node = node.next
pd.Series(lemma_counts).sort_values(ascending=False).head()
```

> **Export Tips**: DataFrame → `df.to_csv('lemma_freq.csv')` → Excel で可視化。

---

### 4. よく使う CQL パターン

| 目的   | CQL 例                    | 説明         |               |
| ---- | ------------------------ | ---------- | ------------- |
| 品詞指定 | `[pos="名詞,固有名詞"]`        | 固有名詞のみ抽出   |               |
| 語形変化 | `[lemma="行く"]"ない"?`      | 「行く」「行かない」 |               |
| 共起距離 | `"ありがとう" .{0,5} "ございます"` | 距離0〜5語     |               |
| 正規表現 | \`"(爆笑                   | 草)"\`      | ネットスラング複数パターン |

---

### 5. 留意点 & よくある罠

* **R18/SNS データ**: プライバシー・倫理審査を確認。
* **書き言葉 vs. 話し言葉**: コーパス間比較は媒体・年代のバイアスに注意。
* **Too Big Trap**: 全データを一気に DL→解析すると時間浪費。サブセットでパイロット。
* **表記ゆれ**: UniDic 形態素解析でも旧仮名や外字は要手補正。

---

### 6. 引用・ライセンス表記テンプレ

```
国立国語研究所『現代日本語書き言葉均衡コーパス（BCCWJ）』, Version 2.1, 2024-03.
NINJAL-Lab UI を用いて 2025-05-09 に取得。
```

> 再現性と課題要件に応じて、コーパス名、バージョン、取得日、検索条件など、追跡に必要な情報を明記する。

---

### 7. 便利リンク

* NINJAL コーパス検索: [https://lab.ninjal.ac.jp/](https://lab.ninjal.ac.jp/)
* UniDic GitHub: [https://github.com/worksapplications/UniDic](https://github.com/worksapplications/UniDic)
* AntConc Download: [https://www.laurenceanthony.net/software/antconc](https://www.laurenceanthony.net/software/antconc)
* Sketch Engine 学術トライアル: [https://www.sketchengine.eu/](https://www.sketchengine.eu/)

---

> **次のステップで困ったら、ワニ先生に聞いてや！**

## Positivist Statistical Toolkit – 実証統計解析ガイド

---

### 1. 目的と前提

* **目的**: 因果・相関・傾向を数値で示し、一般化する。
* **前提**: 測定可能な変数、サンプルが統計的に扱える。

---

### 2. 5 Step ワークフロー

| Step | タスク                   | チェックポイント      |
| ---- | --------------------- | ------------- |
| 1    | 研究質問 → 仮説 (H1/H0) 定式化 | 反証可能性？方向性？    |
| 2    | 変数のオペレーショナライゼーション     | 信頼性のある尺度？     |
| 3    | サンプル設計 & 倫理・権利確認         | n の根拠・所属先要件・データ条件   |
| 4    | データ収集 & 前処理           | 欠損処理・正規性検定    |
| 5    | 統計分析 & 解釈             | t/F 検定・回帰・効果量 |

---

### 3. 統計手法早見表

| 目的   | 手法                | 例          | ソフト       |
| ---- | ----------------- | ---------- | --------- |
| 群差   | t 検定, ANOVA       | 男女の使用頻度差   | JASP, R   |
| 相関   | Pearson, Spearman | SNS 時間とスコア | R, Python |
| 予測   | 重回帰, GLM          | 年齢→語彙多様度   | R lm()    |
| カテゴリ | χ² 検定             | 方言×性別 分布   | Excel, R  |

---

### 4. 再現性チェックリスト

* [ ] 分析スクリプトを GitHub 公開
* [ ] データ辞書を作成
* [ ] 効果量と信頼区間を報告
* [ ] α 水準と多重検定補正を明記

---

### 5. よくある落とし穴 & 処方箋

| 罠       | 症状         | 処方箋               |
| ------- | ---------- | ----------------- |
| p 値至上主義 | p<.05 だけ強調 | 効果量, CI を併記       |
| 根拠のない小標本  | 複雑なモデルに対して標本設計の説明がない   | 問い・モデル・推定に対応する標本根拠を示す           |
| 仮説の後出し  | 分析後に仮説構築   | Preregister (OSF) |

---

### 6. ソフト & リソース

* **R**: tidyverse, lm, ggplot2
* **JASP / Jamovi**: GUI で心理統計
* **Power Analysis**: G\*Power online

> **Tip**: `/mode 5` で「統計コード生成して」と依頼すると R/Python 雛形が返る。

---

*次のステップで困ったら、ワニ先生に聞いてや！*
