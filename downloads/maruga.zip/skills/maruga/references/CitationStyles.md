# Citation Style Quick Guide ― APA 7 / MLA 9 / JIS X 8301:2008

*主要スタイルでの参考文献フォーマット対照表*

---

## 0 使い方

1. 引用したい資料タイプ（図書／論文／Web など）を探す。
2. 対応列の雛形をコピペし、著者名・出版年などを置換。
3. `/mode 5` で「引用整形して」と頼むとワニ先生が自動整形。

> **注**：JIS X 8301 は日本語論文でよく用いられる和文引用形式（“著者—年—頁”）。

---

## 1 単行本（Book）

| 項目 | APA 7 (英語)                                                              | MLA 9 (英語)                                                | JIS X 8301 (和文)               |
| -- | ----------------------------------------------------------------------- | --------------------------------------------------------- | ----------------------------- |
| 雛形 | *Author, A. A.* (Year). *Title: Subtitle* (Edition, if any). Publisher. | *Author Last, First.* *Title: Subtitle.* Publisher, Year. | 著者. 『書名: 副題』, 出版社, 出版年.       |
| 例  | Smith, J. F. (2023). *Digital Hermeneutics.* Routledge.                 | Smith, John F. *Digital Hermeneutics.* Routledge, 2023.   | 佐藤太郎. 『デジタル解釈学』, 岩波書店, 2023年. |

---

## 2 学術論文（Journal Article）

| 項目 | APA 7                                                                                                                                                                            | MLA 9                                                                                                                                        | JIS X 8301                                                            |
| -- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------- |
| 雛形 | Author, A. A., & Author, B. B. (Year). Title of article. *Title of Journal, Volume*(Issue), pp–pp. [https://doi.org/xx](https://doi.org/xx)                                      | Author Last, First, and Second Author. "Title of Article." *Title of Journal* vol.no (Year): pp–pp. DOI.                                     | 著者. 「論文名」『雑誌名』巻(号), pp–pp, 発行年. DOI                                   |
| 例  | Tanaka, M., & Yamada, K. (2024). Historical pragmatics in Edo-period letters. *Japanese Linguistics, 40*(2), 123–145. [https://doi.org/10.1234/abc](https://doi.org/10.1234/abc) | Tanaka, Masao, and Keiko Yamada. "Historical Pragmatics in Edo-Period Letters." *Japanese Linguistics* 40.2 (2024): 123‑45. DOI 10.1234/abc. | 田中正雄・山田恵子. 「江戸期書簡の歴史語用論」『日本語学』40(2), 123‑145, 2024年. DOI 10.1234/abc. |

---

## 3 編著書中の章（Book Chapter）

| 項目 | APA 7                                                                                                                     | MLA 9                                                                                                                                 | JIS X 8301                                                                     |
| -- | ------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------ |
| 雛形 | Author, A. A. (Year). Title of chapter. In B. Editor & C. Editor (Eds.), *Title of book* (pp. xx–xx). Publisher.          | Author Last, First. "Chapter Title." *Title of Book*, edited by Editor First Last, Publisher, Year, pp. xx‑xx.                        | 著者. 「章タイトル」B. Editor・C. Editor(編)『書名』, pp. xx‑xx, 出版社, 出版年.                    |
| 例  | García, L. (2022). Coding practices in mixed methods. In R. Creswell & D. Plano (Eds.), *Mixing It Up* (pp. 55‑78). Sage. | García, Laura. "Coding Practices in Mixed Methods." *Mixing It Up*, edited by Robert Creswell and David Plano, Sage, 2022, pp. 55‑78. | 鈴木良子. 「混合研究におけるコーディング」Creswell・Plano(編)『Mixing It Up』, pp. 55‑78, サージ社, 2022年. |

---

## 4 Web ページ / オンライン資料

| 項目 | APA 7                                                                                                                                       | MLA 9                                                                                                                                   | JIS X 8301                                                                                                      |
| -- | ------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| 雛形 | Author, A. A. (Year, Month Day). Title of page. *Site Name.* URL                                                                            | "Title of Page." *Website Name*, Day Month Year, URL. Accessed Day Month Year.                                                          | 「ページタイトル」『サイト名』, 公開日, URL, (参照 年月日).                                                                            |
| 例  | Ministry of Education. (2025, March 12). *Guidelines for Academic Integrity.* MEXT. [https://www.mext.go.jp/ai](https://www.mext.go.jp/ai)  | "Guidelines for Academic Integrity." *MEXT*, 12 Mar. 2025, [https://www.mext.go.jp/ai](https://www.mext.go.jp/ai). Accessed 9 May 2025. | 文部科学省. 「学術インテグリティ指針」『文科省』, 2025‑03‑12, [https://www.mext.go.jp/ai](https://www.mext.go.jp/ai), (2025‑05‑09 参照). |

---

## 5 引用内のページ番号・脚注スタイル早見表

| ケース        | APA 7 (埋込引用)                                 | MLA 9                                | JIS X 8301     |
| ---------- | -------------------------------------------- | ------------------------------------ | -------------- |
| 直接引用 <40 語 | (Tanaka, 2024, p. 130)                       | (Tanaka 130)                         | (田中 2024: 130) |
| ブロック引用     | Indent 0.5 in., no quotes, cite after period | Indent 1 tab, cite after punctuation | 字下げ+括弧引用       |
| 二次引用       | (Suzuki, as cited in Tanaka, 2024)           | qtd. in Tanaka                       | 田中(2024)より引用   |

---

## 6 ツールリンク

* **APA**: [https://apastyle.apa.org/](https://apastyle.apa.org/)
* **MLA**: [https://style.mla.org/](https://style.mla.org/)
* **JIS X 8301** 解説（国立国会図書館）: [https://www.ndl.go.jp/jp/data/](https://www.ndl.go.jp/jp/data/)

> **メモ**：スタイル混在はリジェクト対象になりやすい。提出前に `/mode 5` で "CITECHECK" 実行を忘れずに！

---

\*\*次のステップで困ったら、ワニ先生に聞いてや！

---

## 1.1 単行本（訳書） / Translated Book

| 項目     | APA 7                                                                                                                              | MLA 9                                                                                                       | JIS X 8301                                       |
| ------ | ---------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- | ------------------------------------------------ |
| **雛形** | *Author, A. A.* (Year). *Title of book* (B. B. Translator, Trans.). Publisher. (Original work published Year)                      | *Author Last, First.* *Title of Book*. Translated by Translator First Last, Publisher, Year.                | 著者名．訳者名(訳)．『書名』．出版社，出版年．（原著：出版年）                 |
| **例**  | Foucault, M. (1972). *The archaeology of knowledge* (A. M. Sheridan Smith, Trans.). Pantheon Books. (Original work published 1969) | Foucault, Michel. *The Archaeology of Knowledge*. Translated by A. M. Sheridan Smith, Pantheon Books, 1972. | フーコー，ミシェル．田村 文 (訳)．『知の考古学』．河出書房新社，1974．（原著：1969） |

> **メモ**
>
> * APA では翻訳者名の後に “Trans.” を付け、最後に原著出版年を括弧書き。
> * MLA は “Translated by …” を著者名の直後に配置。
> * JIS では訳者名の後に (訳) を付し、末尾に原著年を示して区別。
