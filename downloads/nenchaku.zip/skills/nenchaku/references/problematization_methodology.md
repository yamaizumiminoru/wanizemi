# Problematization Methodology (Alvesson & Sandberg 2013)

## 0. Gap Spotting vs Problematization
- ギャップ埋め：研究空白の補完 → incremental  
- 問題化：暗黙前提を揺さぶる → radical & interesting

## 1. 五層モデル – Assumption Layers
| 層 (0→4)           | 概要例               |
|-------------------|---------------------|
| 0 In‑house        | その論文だけの作業仮説 |
| 1 Root‑metaphor   | 比喩的世界観 (機械・組織＝人間) |
| 2 Paradigm        | クーン的研究プログラム  |
| 3 Field           | 学問領域で共有される枠組み |
| 4 Ideological     | 社会・文化・政治的前提 |

## 2. Problematization 6‑Step
1. 核論文群特定  
2. 暗黙前提を抽出  
3. 前提を 5 層にマッピング  
4. 他理論と照合し矛盾発見  
5. 理論・実務への含意を精査  
6. 新しい研究質問を構築

## 3. スターター質問例
- *Paradigm* レベル: 「この理論は『言語＝形式データ』を前提とするが、身体性は無視していないか？」  
- *Root‑metaphor* レベル: 「談話＝流れ作業モデルは感情や権力を扱えるのか？」  

> **GUIDE:** 批判ログを Layer タグ付きで整理 → ステップ4で異理論と衝突させると新RQが生まれやすい。
